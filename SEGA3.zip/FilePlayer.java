import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class FilePlayer {

    private static final String TONE_FOLDER = "c:\\Users\\nguye\\Desktop\\FilePlayer\\Sounds\\";
    // global order: 0:do, 1:re, 2:mi, 3:fa, 4:sol, 5:la, 6:si, 7:dooctave
    protected static final Object lock = new Object();
    protected static int turn = 0;            // which overall tone index should be played next (0..7)
    protected static int octaveReadyCount = 0;// how many threads reached dooctave
    protected static boolean octaveRelease = false; // set when both reached dooctave

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Sequence should be: do, re, mi, fa, sol, la, si, do-octave (played by both)");
        Thread1 t1 = new Thread1("Thread-1"); // plays do,mi,sol,si,dooctave (0,2,4,6,7)
        Thread2 t2 = new Thread2("Thread-2"); // plays re,fa,la,dooctave (1,3,5,7)

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("Done!");
    }

    // Plays the WAV file corresponding to the tone index (0..7)
    protected static void playTone(int toneIndex) {
        String[] tones = {"do", "re", "mi", "fa", "sol", "la", "si", "dooctave"};
        String toneName = tones[toneIndex];
        String filePath = TONE_FOLDER + toneName + ".wav";

        try {
            
            File soundFile = new File(filePath);
            AudioInputStream in = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(in);
            clip.start();

            // block until clip finishes (keeps sequencing correct)
            Thread.sleep(clip.getMicrosecondLength() / 1300);

            System.out.println("FINISHED playing: " + toneName + "  (toneIndex=" + toneIndex + ")");
        } catch (Exception e) {
            System.err.println("Error playing " + toneName + ": " + e.getMessage());
        }
    }
}

class Thread1 extends Thread {
    private final int[] myTones = {0, 2, 4, 6, 7};

    public Thread1(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int toneIndex : myTones) {
            // wait until it's this tone's turn
            synchronized (FilePlayer.lock) {
                while (FilePlayer.turn != toneIndex) {
                    try {

                        FilePlayer.lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                // Special handling for dooctave: coordinate so both start playing together
                if (toneIndex == 7) {
                    System.out.println(getName() + " reached dooctave and is coordinating with other thread.");
                    FilePlayer.octaveReadyCount++;
                    System.out.println(getName() + " octaveReadyCount -> " + FilePlayer.octaveReadyCount);

                    if (FilePlayer.octaveReadyCount < 2) {
                        // first arriver waits until the other arrives and sets release
                        try {
                            while (!FilePlayer.octaveRelease) {
                                FilePlayer.lock.wait();
                            }
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    } else {
                        // second arriver: release both
                        FilePlayer.octaveRelease = true;
                        FilePlayer.lock.notifyAll();
                        System.out.println(getName() + " is LAST to arrive at dooctave and released both.");
                    }
                    // exit synchronized block so both can play simultaneously
                }

                // For non-dooctave tones we leave synchronized block before playing (so other thread can't start early)
                // But we must not advance the turn until after the tone is played.
            }

            // Play the tone outside the synchronized block to allow both dooctave plays to overlap
            FilePlayer.playTone(toneIndex);
            System.out.println(getName() + " played toneIndex: " + toneIndex);

            // After playing, advance turn (only if turn still equals toneIndex -> prevents double increment at octave)
            synchronized (FilePlayer.lock) {
                if (FilePlayer.turn == toneIndex) {
                    FilePlayer.turn++;
                    FilePlayer.lock.notifyAll();
                    System.out.println(getName() + " advanced turn to " + FilePlayer.turn);
                } else {
                    // another thread may have advanced it (this happens for the second octave thread)
                    System.out.println(getName() + " found turn already advanced to " + FilePlayer.turn);
                }
            }

            // small sleep to reduce scheduling weirdness (optional)
            try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        }
    }
}

class Thread2 extends Thread {
    private final int[] myTones = {1, 3, 5, 7};

    public Thread2(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int toneIndex : myTones) {
            // wait until it's this tone's turn
            synchronized (FilePlayer.lock) {
                while (FilePlayer.turn != toneIndex) {
                    try {
                        
                        FilePlayer.lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                // Special handling for dooctave
                if (toneIndex == 7) {
                    System.out.println(getName() + " reached dooctave and is coordinating with other thread.");
                    FilePlayer.octaveReadyCount++;
                    System.out.println(getName() + " octaveReadyCount -> " + FilePlayer.octaveReadyCount);

                    if (FilePlayer.octaveReadyCount < 2) {
                        try {
                            while (!FilePlayer.octaveRelease) {
                                FilePlayer.lock.wait();
                            }
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    } else {
                        FilePlayer.octaveRelease = true;
                        FilePlayer.lock.notifyAll();
                        System.out.println(getName() + " is LAST to arrive at dooctave and released both.");
                    }
                }
            }

            // Play the tone outside the synchronized block so the two dooctave plays can overlap
            FilePlayer.playTone(toneIndex);
            System.out.println(getName() + " played toneIndex: " + toneIndex);

            // After playing, advance turn (only one thread will actually do the increment for octave)
            synchronized (FilePlayer.lock) {
                if (FilePlayer.turn == toneIndex) {
                    FilePlayer.turn++;
                    FilePlayer.lock.notifyAll();
                    System.out.println(getName() + " advanced turn to " + FilePlayer.turn);
                } else {
                    System.out.println(getName() + " found turn already advanced to " + FilePlayer.turn);
                }
            }

            try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        }
    }
}
