import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class FilePlayer2 {

    private static final String TONE_FOLDER = "c:\\Users\\nguye\\Desktop\\FilePlayer\\Sounds\\";
    protected static final Object lock = new Object();

    protected static int turn = 0;
    protected static int[] melody;

    protected static final String[] tones = {"do", "re", "mi", "fa", "sol", "la", "si", "dooctave"};

    public static void main(String[] args) throws InterruptedException {

        melody = new int[]{
            0,0,4,4,5,5,4, 3,3,2,2,1,1,0,
            4,4,3,3,2,2,1, 4,4,3,3,2,2,1,
            0,0,4,4,5,5,4, 3,3,2,2,1,1,0
        };

        System.out.println("Playing Twinkle Twinkle Little Star...");

        Thread t1 = new Thread1("Thread-1");
        Thread t2 = new Thread2("Thread-2");

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("Done!");
    }

    protected static void playTone(int toneIndex) {
        String toneName = tones[toneIndex];
        String filePath = TONE_FOLDER + toneName + ".wav";

        try {
            File soundFile = new File(filePath);
            AudioInputStream in = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(in);
            clip.start();

            Thread.sleep(clip.getMicrosecondLength() / 1500);
            System.out.println("FINISHED: " + toneName);
        } catch (Exception e) {
            System.err.println("Error playing " + toneName + ": " + e.getMessage());
        }
    }
}

class Thread1 extends Thread {

    private final boolean[] allowed = {
        true, false, true, false, true, false, true, true
    };

    public Thread1(String name) { super(name); }

    @Override
    public void run() {
        while (true) {
            int tone;

            synchronized (FilePlayer2.lock) {
                if (FilePlayer2.turn >= FilePlayer2.melody.length)
                    return;

                while (!allowed[FilePlayer2.melody[FilePlayer2.turn]]) {
                    try {
                        FilePlayer2.lock.wait();
                        if (FilePlayer2.turn >= FilePlayer2.melody.length)
                            return;
                    } catch (InterruptedException e) { return; }
                }

                tone = FilePlayer2.melody[FilePlayer2.turn];

                // *** CLEAR THREAD PRINT ***
                System.out.println("Thread1 plays " + FilePlayer2.tones[tone]);
            }

            FilePlayer2.playTone(tone);

            synchronized (FilePlayer2.lock) {
                FilePlayer2.turn++;
                FilePlayer2.lock.notifyAll();
            }
        }
    }
}

class Thread2 extends Thread {

    private final boolean[] allowed = {
        false, true, false, true, false, true, false, true
    };

    public Thread2(String name) { super(name); }

    @Override
    public void run() {
        while (true) {
            int tone;

            synchronized (FilePlayer2.lock) {
                if (FilePlayer2.turn >= FilePlayer2.melody.length)
                    return;

                while (!allowed[FilePlayer2.melody[FilePlayer2.turn]]) {
                    try {
                        FilePlayer2.lock.wait();
                        if (FilePlayer2.turn >= FilePlayer2.melody.length)
                            return;
                    } catch (InterruptedException e) { return; }
                }

                tone = FilePlayer2.melody[FilePlayer2.turn];

                // *** CLEAR THREAD PRINT ***
                System.out.println("Thread2 plays " + FilePlayer2.tones[tone]);
            }

            FilePlayer2.playTone(tone);

            synchronized (FilePlayer2.lock) {
                FilePlayer2.turn++;
                FilePlayer2.lock.notifyAll();
            }
        }
    }
}
